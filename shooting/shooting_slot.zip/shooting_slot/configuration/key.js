module.exports = {
    JWT_SECRET : 'shootingauthentication'
};