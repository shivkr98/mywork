// const db = require("../../../database/db");
// var jwt = require("jsonwebtoken");

// const JWT = require("jsonwebtoken");

// const { JWT_SECRET } = require("../../../configuration/key");
// var jwt_Decode = require("jwt-decode");
// const { json } = require('body-parser');


// module.exports = {

//     updateRange : (req,res)=>{

//         const token = req.headers["authorization"];
//         var decoded = jwt_Decode(token);
//         adminEmail = decoded.sub.e;


        

//     }

// }